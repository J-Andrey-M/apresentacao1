# Portfólio Profissional — Andrey Maia

Site pessoal e vitrine de serviços de **Andrey Maia**, técnico de suporte em informática e desenvolvedor web. Feito com **Python + Flask**, banco **SQLite** (ou MySQL) e front-end em HTML, CSS e JavaScript puros.

---

## Funcionalidades

### Site público
- **Abertura (hero)**: nome em destaque, foto da bancada, relógio ao vivo e tela de "boot" na primeira visita.
- **01 · Sobre**: apresentação e painel com 3 números expansíveis (computadores atendidos, sistemas web, qualificações).
- **02 · Habilidades**: grade com 6 áreas (Hardware, Suporte, Redes, Programação, IA, Ferramentas) e barras de nível animadas.
- **03 · Serviços**: 5 serviços com atalho para abrir um chamado.
- **04 · Projetos**: projetos em destaque com links para código e demonstração.
- **05 · Avaliações**: depoimentos aprovados, média de notas e formulário para o cliente avaliar (com foto opcional).
- **Help Desk**: formulário "Preciso de ajuda" com escolha do serviço, descrição e foto do problema.
- **06 · Contato**: formulário de mensagem salvo no banco.
- **Experiência**: tema escuro/claro (salvo no navegador), animações ao rolar, botões magnéticos e cursor contextual.

### Painel administrativo (`/admin`)
- Acesso pelo link discreto `•` no rodapé, com login (`Flask-Login`) e senha criptografada.
- **Dashboard** com o total de mensagens, chamados e avaliações pendentes.
- **Mensagens**: ler, marcar como lida/não lida e excluir.
- **Chamados**: ver descrição e foto, mudar o status (*Nova, Contatada, Em andamento, Concluída, Cancelada*) e responder pelo WhatsApp.
- **Avaliações**: aprovar, rejeitar ou excluir antes de aparecerem no site.

### Segurança
- Proteção CSRF em todos os formulários (`Flask-WTF`) e campo *honeypot* contra spam.
- Uploads com nome aleatório (UUID), apenas `.jpg`, `.jpeg`, `.png` e `.webp`, até 5 MB.

---

## Tecnologias

- **Back-end**: Python 3.12, Flask, Flask-SQLAlchemy, Flask-Login, Flask-WTF, python-dotenv, Pillow, PyMySQL
- **Front-end**: HTML5, CSS3 (variáveis e grid), JavaScript puro
- **Banco**: SQLite em `instance/database.db` (MySQL opcional)
- **Visual**: fundo grafite escuro, destaque em ciano `#22D3EE` e azul cobalto `#3D6BFF`; fontes *Syne* (títulos), *Instrument Sans* (texto) e *JetBrains Mono* (detalhes técnicos)

---

## Como rodar no computador

```bash
git clone https://github.com/J-Andrey-M/apresentacao.git
cd apresentacao

# Windows
python -m venv venv
venv\Scripts\activate

# Linux / macOS
python3 -m venv venv
source venv/bin/activate

pip install -r requirements.txt
cp .env.example .env      # no Windows: copy .env.example .env
python app.py
```

- Site: http://127.0.0.1:5000
- Painel: http://127.0.0.1:5000/admin/login

Na primeira execução o Flask cria as tabelas e o usuário administrador com os dados do `.env`.

---

## Configuração (`.env`)

| Variável | Para que serve |
|---|---|
| `SECRET_KEY` | Chave secreta do Flask. Use um texto longo e aleatório. |
| `DATABASE_URL` | Banco de dados. Padrão: SQLite local. |
| `ADMIN_USERNAME` | Usuário do painel. |
| `ADMIN_PASSWORD` | Senha do painel. Troque antes de publicar. |
| `MAX_UPLOAD_SIZE` | Tamanho máximo de upload em bytes (padrão 5 MB). |

Para usar MySQL/MariaDB:

```env
DATABASE_URL=mysql+pymysql://usuario:senha@localhost:3306/nome_do_banco
```

---

## Estrutura

```text
├── app.py              # Rotas do site e do painel
├── config.py           # Configurações (lidas do .env)
├── models.py           # Tabelas: Admin, ContactMessage, HelpRequest, Review
├── forms.py            # Formulários e validações
├── helpers.py          # Upload seguro e funções auxiliares
├── requirements.txt
├── .env.example
├── instance/           # Banco SQLite (não versionado)
├── uploads/            # Fotos de chamados e avaliações (não versionado)
├── templates/
│   ├── index.html      # Página principal
│   ├── admin/          # Telas do painel
│   └── errors/         # Páginas 404 e 500
└── static/
    ├── css/site.css    # Estilo do site público
    ├── css/style.css   # Base usada pelo painel e páginas de erro
    ├── css/admin.css   # Estilo do painel
    ├── js/script.js    # Interações do site
    ├── js/admin.js     # Interações do painel
    └── images/         # Imagens do site
```

---

## Publicação

O projeto roda em qualquer hospedagem Python (ex.: PythonAnywhere). Antes de publicar, defina `SECRET_KEY` e `ADMIN_PASSWORD` fortes no `.env` do servidor.

---

Projeto desenvolvido por **Andrey Maia**. Todos os direitos reservados.
