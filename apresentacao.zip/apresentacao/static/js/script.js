/* ============================================
   ANDREY MAIA — PORTFOLIO JAVASCRIPT
   Direção de arte "Bancada Técnica"
   ============================================ */

document.addEventListener('DOMContentLoaded', () => {

  const root = document.documentElement;
  const body = document.body;
  const reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const finePointer = window.matchMedia('(hover: hover) and (pointer: fine)').matches;

  // ---------- Split de letras do hero ----------
  document.querySelectorAll('[data-split]').forEach(el => {
    const text = el.textContent.trim();
    el.textContent = '';
    [...text].forEach((ch, i) => {
      const span = document.createElement('span');
      span.className = 'ch';
      span.style.setProperty('--i', i + (el.classList.contains('ht-2') ? 6 : 0));
      span.textContent = ch;
      el.appendChild(span);
    });
  });

  // ---------- Boot (POST) ----------
  const boot = document.getElementById('boot');
  const bootLog = document.getElementById('bootLog');
  const bootBar = document.getElementById('bootBar');

  function finishBoot() {
    if (boot) boot.classList.add('is-done');
    body.classList.remove('is-booting');
    body.classList.add('is-ready');
    setTimeout(() => boot && boot.remove(), 1000);
  }

  (function runBoot() {
    let seen = false;
    try { seen = sessionStorage.getItem('am-booted') === '1'; } catch (e) { }

    if (!boot || reduceMotion) { finishBoot(); return; }

    const lines = [
      ['CPU .................................', 'OK'],
      ['MEMÓRIA 100+ MÁQUINAS DIAGNOSTICADAS', 'OK'],
      ['REDE  UniFi / Cisco / Patch Panel ...', 'LINK'],
      ['HELP DESK  N1 / N2 ..................', 'ONLINE'],
      ['STACK  Python · Flask · SQLite · JS .', 'OK'],
      ['CARREGANDO PORTFÓLIO ................', '100%'],
    ];
    const step = seen ? 40 : 150;
    let i = 0;

    const tick = () => {
      if (i < lines.length) {
        const [label, status] = lines[i];
        bootLog.innerHTML += `${label} <b>[${status}]</b>\n`;
        bootBar.style.width = `${((i + 1) / lines.length) * 100}%`;
        i++;
        setTimeout(tick, step);
      } else {
        try { sessionStorage.setItem('am-booted', '1'); } catch (e) { }
        setTimeout(finishBoot, seen ? 80 : 280);
      }
    };

    // espera o load (com teto) para não revelar imagens pela metade
    let started = false;
    const start = () => { if (!started) { started = true; tick(); } };
    if (document.readyState === 'complete') start();
    else {
      window.addEventListener('load', start, { once: true });
      setTimeout(start, 1200);
    }
  })();

  // ---------- Tema ----------
  const themeToggle = document.getElementById('themeToggle');
  if (!root.getAttribute('data-theme')) root.setAttribute('data-theme', 'dark');

  themeToggle?.addEventListener('click', () => {
    const next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', next);
    try { localStorage.setItem('portfolio-theme', next); } catch (e) { }
    const meta = document.querySelector('meta[name="theme-color"]');
    if (meta) meta.setAttribute('content', next === 'dark' ? '#0B0E11' : '#E5E8EB');
  });

  // ---------- Menu mobile ----------
  const menuToggle = document.getElementById('menuToggle');
  const mobileMenu = document.getElementById('mobileMenu');

  function setMenu(open) {
    body.classList.toggle('menu-open', open);
    menuToggle?.setAttribute('aria-expanded', String(open));
    mobileMenu?.setAttribute('aria-hidden', String(!open));
    body.style.overflow = open ? 'hidden' : '';
  }

  menuToggle?.addEventListener('click', () => setMenu(!body.classList.contains('menu-open')));
  mobileMenu?.querySelectorAll('a').forEach(a => a.addEventListener('click', () => setMenu(false)));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

  // ---------- Âncoras suaves (ignora href="#") ----------
  document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', e => {
      const href = anchor.getAttribute('href');
      if (href.length < 2) { e.preventDefault(); return; }
      const target = document.querySelector(href);
      if (target) {
        e.preventDefault();
        target.scrollIntoView({ behavior: reduceMotion ? 'auto' : 'smooth' });
      }
    });
  });

  // ---------- Manifesto: palavras acendem com o scroll ----------
  const manifesto = document.querySelector('[data-scrub]');
  let manifestoWords = [];
  if (manifesto) {
    const hot = ['liga,', 'conecta', 'resolve.'];
    const words = manifesto.textContent.trim().split(/\s+/);
    manifesto.textContent = '';
    words.forEach(w => {
      const s = document.createElement('span');
      s.className = 'w' + (hot.includes(w) ? ' is-hot' : '');
      s.textContent = w;
      manifesto.appendChild(s);
      manifesto.appendChild(document.createTextNode(' '));
    });
    manifestoWords = [...manifesto.querySelectorAll('.w')];
  }

  // ---------- Scroll loop (rAF) ----------
  const header = document.getElementById('siteHeader');
  const progress = document.getElementById('scrollProgress');
  const scrollPct = document.getElementById('scrollPct');
  const backToTop = document.getElementById('backToTop');
  const heroTitle = document.querySelector('.hero-title');
  const heroVisual = document.getElementById('heroVisual');
  const wipeZones = document.querySelectorAll('[data-wipe]');
  const parallaxEls = document.querySelectorAll('[data-parallax]');
  const sections = document.querySelectorAll('main section[id]');
  const navLinks = document.querySelectorAll('.nav-links a');

  let ticking = false;
  let mouseX = 0, mouseY = 0;

  function update() {
    const y = window.scrollY;
    const vh = window.innerHeight;
    const max = document.documentElement.scrollHeight - vh;
    const p = max > 0 ? y / max : 0;

    header.classList.toggle('is-scrolled', y > 24);
    if (heroTitle) {
      header.classList.toggle('past-hero', heroTitle.getBoundingClientRect().bottom < 80);
    }
    if (progress) progress.style.transform = `scaleX(${p})`;
    if (scrollPct) scrollPct.textContent = String(Math.round(p * 100)).padStart(3, '0') + '%';
    backToTop?.classList.toggle('visible', y > vh * 1.2);

    // nav ativa
    let current = '';
    sections.forEach(s => {
      if (s.offsetTop - vh * 0.35 <= y) current = s.id;
    });
    navLinks.forEach(l => l.classList.toggle('active', l.getAttribute('href') === `#${current}`));

    if (!reduceMotion) {
      // hero: imagem sobe mais devagar que o texto
      if (heroVisual) {
        const sy = Math.min(y, vh) * -0.12;
        heroVisual.style.setProperty('--px', `${mouseX * 14}px`);
        heroVisual.style.setProperty('--py', `${sy + mouseY * 14}px`);
      }

      // manifesto
      if (manifestoWords.length) {
        const r = manifesto.getBoundingClientRect();
        const t = Math.min(Math.max((vh * 0.85 - r.top) / (r.height + vh * 0.35), 0), 1);
        const lit = Math.round(t * manifestoWords.length);
        manifestoWords.forEach((w, i) => {
          w.classList.toggle('on', i < lit);
          w.classList.toggle('hot', i < lit && w.classList.contains('is-hot'));
        });
      }

      // zonas invertidas abrem como cortina
      wipeZones.forEach(z => {
        const r = z.getBoundingClientRect();
        const t = Math.min(Math.max((vh - r.top) / (vh * 0.7), 0), 1);
        z.style.setProperty('--wipe', t.toFixed(3));
      });

      // parallax sutil
      parallaxEls.forEach(el => {
        const r = el.getBoundingClientRect();
        const speed = parseFloat(el.dataset.parallax) || 0.08;
        const offset = (r.top + r.height / 2 - vh / 2) * -speed;
        el.style.setProperty('--py', `${offset - r.height * 0.09}px`);
      });
    } else {
      manifestoWords.forEach(w => w.classList.add('on'));
    }

    ticking = false;
  }

  function requestUpdate() {
    if (!ticking) { ticking = true; requestAnimationFrame(update); }
  }

  window.addEventListener('scroll', requestUpdate, { passive: true });
  window.addEventListener('resize', requestUpdate);
  update();

  backToTop?.addEventListener('click', () => window.scrollTo({ top: 0, behavior: reduceMotion ? 'auto' : 'smooth' }));

  // mouse → profundidade no hero
  if (finePointer && !reduceMotion) {
    window.addEventListener('mousemove', e => {
      mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
      mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
      if (window.scrollY < window.innerHeight) requestUpdate();
    }, { passive: true });
  }

  // ---------- Revelação ao scroll (com stagger por grupo) ----------
  const revealEls = document.querySelectorAll('[data-reveal]');
  const groups = new Map();
  revealEls.forEach(el => {
    const parent = el.parentElement;
    const idx = groups.get(parent) || 0;
    el.style.setProperty('--d', `${Math.min(idx, 6) * 90}ms`);
    groups.set(parent, idx + 1);
  });

  const revealObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        revealObserver.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12, rootMargin: '0px 0px -60px 0px' });

  revealEls.forEach(el => revealObserver.observe(el));

  // ---------- Medidores segmentados ----------
  const meters = document.querySelectorAll('.meter');
  const meterObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const m = entry.target;
      const lvl = parseInt(m.dataset.level, 10) || 0;
      const siblings = [...m.closest('.skill-list').querySelectorAll('.meter')];
      m.style.setProperty('--d', `${siblings.indexOf(m) * 120 + 200}ms`);
      m.style.setProperty('--lvl', `${lvl}%`);
      if (lvl >= 95) m.classList.add('is-peak');
      m.classList.add('is-on');
      meterObserver.unobserve(m);
    });
  }, { threshold: 0.4 });
  meters.forEach(m => meterObserver.observe(m));

  // ---------- Contadores ----------
  const counters = document.querySelectorAll('.stat-number[data-count]');
  const counterObserver = new IntersectionObserver(entries => {
    entries.forEach(entry => {
      if (!entry.isIntersecting) return;
      const el = entry.target;
      const target = parseInt(el.dataset.count, 10);
      const suffix = el.dataset.suffix || '';
      const duration = reduceMotion ? 0 : 1400;
      const start = performance.now();
      const step = now => {
        const t = duration ? Math.min((now - start) / duration, 1) : 1;
        const eased = 1 - Math.pow(1 - t, 4);
        el.textContent = Math.round(target * eased) + suffix;
        if (t < 1) requestAnimationFrame(step);
      };
      requestAnimationFrame(step);
      counterObserver.unobserve(el);
    });
  }, { threshold: 0.5 });
  counters.forEach(c => counterObserver.observe(c));

  // ---------- Painel de leituras (accordion) ----------
  const expandableStats = document.querySelectorAll('.stat-item[data-expandable]');
  const statsContainer = document.querySelector('.about-stats');
  let hoverTimeout = null;

  function expandStat(stat) {
    expandableStats.forEach(s => {
      s.classList.remove('expanded');
      s.setAttribute('aria-expanded', 'false');
    });
    stat.classList.add('expanded');
    stat.setAttribute('aria-expanded', 'true');
    statsContainer.classList.add('has-expanded');
  }

  function collapseAll() {
    expandableStats.forEach(s => {
      s.classList.remove('expanded');
      s.setAttribute('aria-expanded', 'false');
    });
    statsContainer.classList.remove('has-expanded');
  }

  expandableStats.forEach(stat => {
    stat.setAttribute('role', 'button');
    stat.setAttribute('aria-expanded', 'false');

    const toggle = () => stat.classList.contains('expanded') ? collapseAll() : expandStat(stat);

    stat.addEventListener('click', e => {
      if (e.target.closest('a')) return;
      clearTimeout(hoverTimeout);
      toggle();
    });

    stat.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
    });

    if (finePointer) {
      stat.addEventListener('mouseenter', () => {
        clearTimeout(hoverTimeout);
        hoverTimeout = setTimeout(() => {
          if (!stat.classList.contains('expanded')) expandStat(stat);
        }, 300);
      });
    }
  });

  if (statsContainer && finePointer) {
    statsContainer.addEventListener('mouseleave', () => {
      clearTimeout(hoverTimeout);
      hoverTimeout = setTimeout(collapseAll, 400);
    });
  }

  // ---------- Efeito de digitação ----------
  const typedElement = document.querySelector('.typed-text');
  if (typedElement && !reduceMotion) {
    const texts = [
      'Técnico de Suporte em Informática',
      'Desenvolvedor Web',
      'Especialista em Infraestrutura'
    ];
    let textIndex = 0, charIndex = texts[0].length, isDeleting = true;

    const typeEffect = () => {
      const current = texts[textIndex];
      charIndex += isDeleting ? -1 : 1;
      typedElement.textContent = current.substring(0, charIndex);

      let speed = isDeleting ? 28 : 55;
      if (!isDeleting && charIndex === current.length) {
        speed = 2200; isDeleting = true;
      } else if (isDeleting && charIndex === 0) {
        isDeleting = false;
        textIndex = (textIndex + 1) % texts.length;
        speed = 400;
      }
      setTimeout(typeEffect, speed);
    };
    setTimeout(typeEffect, 3500);
  }

  // ---------- Relógio (Fortaleza) ----------
  const clock = document.getElementById('liveClock');
  if (clock) {
    const fmt = new Intl.DateTimeFormat('pt-BR', {
      hour: '2-digit', minute: '2-digit', second: '2-digit', timeZone: 'America/Fortaleza'
    });
    const tickClock = () => { clock.textContent = fmt.format(new Date()); };
    tickClock();
    setInterval(tickClock, 1000);
  }

  // ---------- Número de ticket ----------
  const ticketId = document.getElementById('ticketId');
  const newTicket = () => {
    if (ticketId) ticketId.textContent = '#AM-' + String(Math.floor(1000 + Math.random() * 9000));
  };
  newTicket();

  // ---------- Cursor contextual ----------
  const cursor = document.getElementById('cursor');
  const cursorLabel = document.getElementById('cursorLabel');
  if (cursor && finePointer && !reduceMotion) {
    window.addEventListener('mousemove', e => {
      cursor.style.setProperty('--cx', `${e.clientX}px`);
      cursor.style.setProperty('--cy', `${e.clientY}px`);
    }, { passive: true });

    document.querySelectorAll('[data-cursor]').forEach(el => {
      el.addEventListener('mouseenter', () => {
        cursorLabel.textContent = el.dataset.cursor;
        cursor.classList.add('is-active');
      });
      el.addEventListener('mouseleave', () => cursor.classList.remove('is-active'));
    });
  }

  // ---------- Botões magnéticos ----------
  if (finePointer && !reduceMotion) {
    document.querySelectorAll('[data-magnetic]').forEach(btn => {
      btn.addEventListener('mousemove', e => {
        const r = btn.getBoundingClientRect();
        btn.style.setProperty('--mx', `${(e.clientX - r.left - r.width / 2) * 0.18}px`);
        btn.style.setProperty('--my', `${(e.clientY - r.top - r.height / 2) * 0.3}px`);
      });
      btn.addEventListener('mouseleave', () => {
        btn.style.setProperty('--mx', '0px');
        btn.style.setProperty('--my', '0px');
      });
    });
  }

  // ---------- Envio de formulários via fetch ----------
  function handleFormSubmit(form, successMsg) {
    form.addEventListener('submit', e => {
      e.preventDefault();

      const ratingInput = form.querySelector('#ratingValue');
      if (ratingInput && !ratingInput.value) {
        const rating = form.querySelector('#starRating');
        rating?.querySelector('.star-select')?.focus();
        rating?.animate(
          [{ transform: 'translateX(0)' }, { transform: 'translateX(-6px)' }, { transform: 'translateX(6px)' }, { transform: 'translateX(0)' }],
          { duration: 300 }
        );
        return;
      }

      const btn = form.querySelector('.btn-submit');
      const originalText = btn.innerHTML;
      btn.innerHTML = 'Enviando<span class="btn-arrow">…</span>';
      btn.classList.add('is-loading');

      fetch(form.action, {
        method: 'POST',
        body: new FormData(form),
        headers: { 'X-Requested-With': 'XMLHttpRequest' }
      })
        .then(response => response.json())
        .then(data => {
          if (data.success) {
            btn.innerHTML = `✓ ${data.message || successMsg}`;
            form.reset();
            form.querySelectorAll('.star-select').forEach(s => s.classList.remove('active', 'hover'));
            const preview = form.querySelector('.file-upload-preview');
            if (preview) preview.style.display = 'none';
            if (form.id === 'helpForm') newTicket();
          } else {
            btn.innerHTML = `✕ ${data.message || 'Erro ao enviar.'}`;
          }
          setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.remove('is-loading');
          }, 4000);
        })
        .catch(() => {
          btn.innerHTML = '✕ Erro de conexão.';
          setTimeout(() => {
            btn.innerHTML = originalText;
            btn.classList.remove('is-loading');
          }, 3000);
        });
    });
  }

  const contactForm = document.getElementById('contactForm');
  if (contactForm) handleFormSubmit(contactForm, 'Mensagem enviada!');

  const helpForm = document.getElementById('helpForm');
  if (helpForm) handleFormSubmit(helpForm, 'Solicitação enviada!');

  const reviewForm = document.getElementById('reviewForm');
  if (reviewForm) handleFormSubmit(reviewForm, 'Avaliação enviada!');

  // ---------- Nota (1–5) ----------
  const starRating = document.getElementById('starRating');
  if (starRating) {
    const stars = starRating.querySelectorAll('.star-select');
    const ratingInput = document.getElementById('ratingValue');
    const paint = (value, cls) => stars.forEach(s => s.classList.toggle(cls, parseInt(s.dataset.value, 10) <= value));

    stars.forEach(star => {
      const value = parseInt(star.dataset.value, 10);
      star.setAttribute('role', 'radio');
      star.setAttribute('aria-checked', 'false');
      star.addEventListener('click', () => {
        ratingInput.value = value;
        paint(value, 'active');
        stars.forEach(s => s.setAttribute('aria-checked', String(s === star)));
      });
      star.addEventListener('mouseenter', () => paint(value, 'hover'));
    });

    starRating.addEventListener('mouseleave', () => paint(0, 'hover'));
  }

  // ---------- Pré-visualização de imagem ----------
  function setupImagePreview(inputId, previewId, imgId) {
    const input = document.getElementById(inputId);
    const preview = document.getElementById(previewId);
    const img = document.getElementById(imgId);
    if (!input || !preview || !img) return;

    input.addEventListener('change', e => {
      const file = e.target.files[0];
      if (!file) return;
      const allowed = ['image/jpeg', 'image/png', 'image/webp'];
      if (!allowed.includes(file.type)) {
        alert('Formato de imagem não permitido. Use JPG, PNG ou WebP.');
        input.value = '';
        return;
      }
      const reader = new FileReader();
      reader.onload = ev => {
        img.src = ev.target.result;
        preview.style.display = 'block';
      };
      reader.readAsDataURL(file);
    });
  }

  setupImagePreview('help-image', 'helpImagePreview', 'helpPreviewImg');
  setupImagePreview('review-image', 'reviewImagePreview', 'reviewPreviewImg');

  // ---------- Flash messages: auto-dismiss ----------
  setTimeout(() => {
    document.querySelectorAll('.flash-message').forEach(el => {
      el.style.transition = 'opacity .5s, transform .5s';
      el.style.opacity = '0';
      el.style.transform = 'translateX(30px)';
      setTimeout(() => el.remove(), 500);
    });
  }, 5000);
});

// ---------- Global: remover preview ----------
function removePreview(prefix) {
  const input = document.getElementById(prefix + '-image');
  const preview = document.getElementById(prefix + 'ImagePreview');
  if (input) input.value = '';
  if (preview) preview.style.display = 'none';
}
