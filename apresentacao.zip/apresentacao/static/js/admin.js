// Admin Panel JavaScript

document.addEventListener('DOMContentLoaded', () => {
  // Auto dismiss flash messages after 5s
  setTimeout(() => {
    document.querySelectorAll('.admin-flash').forEach(el => {
      el.style.transition = 'opacity 0.4s ease, transform 0.4s ease';
      el.style.opacity = '0';
      el.style.transform = 'translateY(-10px)';
      setTimeout(() => el.remove(), 400);
    });
  }, 5000);
});
