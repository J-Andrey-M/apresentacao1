import os
import uuid
import re
import mimetypes
from werkzeug.utils import secure_filename
from flask import current_app


ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}
ALLOWED_MIMETYPES = {'image/jpeg', 'image/png', 'image/webp'}


def allowed_file(filename):
    """Verifica se a extensão do arquivo é permitida."""
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS


def save_upload(file, subfolder='reviews'):
    """
    Salva um arquivo de upload de forma segura.
    Retorna o nome do arquivo salvo ou None em caso de erro.
    """
    if not file or file.filename == '':
        return None

    if not allowed_file(file.filename):
        return None

    # Verificar MIME type
    mime = mimetypes.guess_type(file.filename)[0]
    if mime not in ALLOWED_MIMETYPES:
        return None

    # Gerar nome seguro com UUID
    ext = file.filename.rsplit('.', 1)[1].lower()
    safe_name = f"{uuid.uuid4().hex}.{ext}"

    # Criar diretório se não existir
    upload_dir = os.path.join(current_app.config['UPLOAD_FOLDER'], subfolder)
    os.makedirs(upload_dir, exist_ok=True)

    # Salvar arquivo
    filepath = os.path.join(upload_dir, safe_name)
    file.save(filepath)

    return safe_name


def delete_upload(filename, subfolder='reviews'):
    """Remove um arquivo de upload do filesystem."""
    if not filename:
        return

    filepath = os.path.join(
        current_app.config['UPLOAD_FOLDER'], subfolder, filename
    )
    if os.path.exists(filepath):
        os.remove(filepath)


def validate_email(email):
    """Validação básica de formato de e-mail."""
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))


def validate_whatsapp(phone):
    """Validação básica de número de WhatsApp brasileiro."""
    # Remove caracteres não numéricos
    digits = re.sub(r'\D', '', phone)
    # Aceita 10-13 dígitos (com ou sem código do país)
    return 10 <= len(digits) <= 13
