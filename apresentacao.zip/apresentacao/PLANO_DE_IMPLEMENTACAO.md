# Transformação para Portfólio Dinâmico (Flask + SQLite)

A conversão do seu site atual (HTML estático) para um sistema Full-Stack usando Python/Flask exigirá uma reestruturação nas pastas e a adição do backend.

## ⚠️ User Review Required

Vou modificar a estrutura do seu projeto atual para o padrão do Flask. Isso significa mover os arquivos CSS, JS e imagens para uma pasta `static/` e o HTML para `templates/`. Confirme se podemos prosseguir com essa refatoração no repositório atual.

## Proposed Changes

### Estrutura de Diretórios
Vamos reorganizar o repositório para:
- `app.py` (Backend principal)
- `database.py` (Criação das tabelas)
- `.env` (Configurações e credenciais)
- `templates/` (Páginas HTML dinâmicas)
- `static/` (Arquivos estáticos e uploads)

---

### Backend (Python/Flask)

#### [NEW] `app.py`
O arquivo principal do Flask. Conterá:
- Configuração de `SECRET_KEY` e leitura do `.env`.
- Rota `/` (GET) para renderizar a home page.
- Rota `/contato` (POST) para receber mensagens de ajuda/contato.
- Rota `/avaliar` (POST) para upload de fotos e recebimento de avaliações.
- Rotas `/login` e `/logout` para controle de sessão do Admin.
- Rota protegida `/admin` para gestão de mensagens e aprovação de avaliações.

#### [NEW] `database.py`
Script para criar o banco de dados `portfolio.db` (SQLite) com as tabelas:
- **Mensagens**: `id`, `nome`, `email`, `whatsapp`, `tipo`, `mensagem`.
- **Avaliacoes**: `id`, `nome_cliente`, `servico_prestado`, `comentario`, `caminho_foto`, `aprovada`.

#### [NEW] `.env`
Arquivo com `ADMIN_USER=andrey`, `ADMIN_PASS=suporte123` e `SECRET_KEY`.

---

### Frontend

#### [MODIFY] `index.html` -> Mover para `templates/index.html`
- Atualizaremos os links de CSS, JS e imagens para usar a sintaxe do Jinja2 (`{{ url_for('static', filename='...') }}`).
- **Nova Seção de Avaliações:** Um loop dinâmico (`{% for avaliacao in avaliacoes %}`) que exibe apenas as avaliações marcadas como aprovadas.
- **Formulário de Avaliação:** Um botão que abre um Modal com um form (enctype `multipart/form-data`) para upload de imagem e texto.
- **Formulário de Contato:** Ajustar a "action" do form existente para enviar um POST ao backend.
- **Ícone Discreto Admin:** Adicionar um link quase invisível no footer para a rota `/login`.

#### [NEW] `templates/login.html`
- Uma tela de login minimalista, no estilo dark-navy, mantendo a estética cyber do portfólio.

#### [NEW] `templates/admin.html`
- Um painel restrito para o administrador (Andrey).
- Listagem em tabelas (com design escuro/clean) de todas as **Mensagens/Leads** recebidas.
- Listagem de **Avaliações** pendentes e aprovadas, com botões para `Aprovar` ou `Excluir`.

#### [MODIFY] `style.css` & `script.js` -> Mover para `static/css/` e `static/js/`
- Adicionaremos os estilos e lógicas necessários para o Modal de Avaliação, formulários dinâmicos e painel admin.

## Verification Plan
1. Criar a estrutura e os arquivos.
2. Inicializar o banco de dados via `python database.py`.
3. Subir o servidor local Flask.
4. Testar envio de mensagem de contato, envio de avaliação, login no admin e aprovação da avaliação.
5. Garantir que tudo está pronto para ser enviado ao **PythonAnywhere**.
