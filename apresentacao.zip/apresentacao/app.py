import os
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, send_from_directory, jsonify
)
from flask_login import (
    LoginManager, login_user, logout_user,
    login_required, current_user
)
from flask_wtf.csrf import CSRFProtect
from config import Config
from models import db, Admin, ContactMessage, HelpRequest, Review
from forms import LoginForm, ContactForm, HelpRequestForm, ReviewForm
from helpers import save_upload, delete_upload

# ──────────────────────────────────────
# Inicialização
# ──────────────────────────────────────

app = Flask(__name__)
app.config.from_object(Config)

db.init_app(app)
csrf = CSRFProtect(app)

login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'admin_login'
login_manager.login_message = 'Faça login para acessar esta página.'
login_manager.login_message_category = 'warning'


@login_manager.user_loader
def load_user(user_id):
    return db.session.get(Admin, int(user_id))


def init_app():
    """Cria diretórios, tabelas e admin inicial."""
    # Diretórios
    os.makedirs('instance', exist_ok=True)
    os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'reviews'), exist_ok=True)
    os.makedirs(os.path.join(app.config['UPLOAD_FOLDER'], 'help'), exist_ok=True)

    # Tabelas
    with app.app_context():
        db.create_all()

        # Admin inicial
        admin = Admin.query.filter_by(username=app.config['ADMIN_USERNAME']).first()
        if not admin:
            admin = Admin(username=app.config['ADMIN_USERNAME'])
            admin.set_password(app.config['ADMIN_PASSWORD'])
            db.session.add(admin)
            db.session.commit()
            print(f"[OK] Admin '{app.config['ADMIN_USERNAME']}' criado com sucesso.")
        else:
            print(f"[OK] Admin '{admin.username}' já existe.")


# ──────────────────────────────────────
# Rota de uploads (servir arquivos)
# ──────────────────────────────────────

@app.route('/uploads/<path:filename>')
def uploaded_file(filename):
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# ──────────────────────────────────────
# ROTAS PÚBLICAS
# ──────────────────────────────────────

@app.route('/')
def index():
    """Página principal do portfólio."""
    reviews = Review.query.filter_by(approved=True).order_by(Review.created_at.desc()).all()

    # Calcular média e total de avaliações
    avg_rating = 0
    total_reviews = len(reviews)
    if total_reviews > 0:
        avg_rating = round(sum(r.rating for r in reviews) / total_reviews, 1)

    return render_template(
        'index.html',
        reviews=reviews,
        avg_rating=avg_rating,
        total_reviews=total_reviews
    )


@app.route('/contact', methods=['POST'])
def contact():
    """Recebe mensagem do formulário de contato."""
    form = ContactForm()

    # Honeypot check
    if form.website.data:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Mensagem enviada com sucesso!'})
        flash('Mensagem enviada com sucesso!', 'success')
        return redirect(url_for('index') + '#contact')

    if form.validate_on_submit():
        msg = ContactMessage(
            name=form.name.data.strip(),
            email=form.email.data.strip(),
            whatsapp=form.whatsapp.data.strip() if form.whatsapp.data else None,
            subject=form.subject.data.strip() if form.subject.data else None,
            message=form.message.data.strip()
        )
        db.session.add(msg)
        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Mensagem enviada com sucesso!'})

        flash('Mensagem enviada com sucesso!', 'success')
        return redirect(url_for('index') + '#contact')

    # Erros
    errors = []
    for field, field_errors in form.errors.items():
        for error in field_errors:
            errors.append(error)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': False, 'message': ' '.join(errors)}), 400

    flash(' '.join(errors), 'error')
    return redirect(url_for('index') + '#contact')


@app.route('/help', methods=['POST'])
def help_request():
    """Recebe solicitação de ajuda."""
    form = HelpRequestForm()

    # Honeypot
    if form.website.data:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Solicitação enviada com sucesso!'})
        flash('Solicitação enviada com sucesso!', 'success')
        return redirect(url_for('index') + '#help')

    if form.validate_on_submit():
        image_filename = None
        if form.image.data:
            image_filename = save_upload(form.image.data, 'help')

        hr = HelpRequest(
            name=form.name.data.strip(),
            email=form.email.data.strip(),
            whatsapp=form.whatsapp.data.strip(),
            service=form.service.data if form.service.data else None,
            description=form.description.data.strip(),
            image_filename=image_filename
        )
        db.session.add(hr)
        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Solicitação enviada com sucesso! Entrarei em contato em breve.'})

        flash('Solicitação enviada com sucesso! Entrarei em contato em breve.', 'success')
        return redirect(url_for('index') + '#help')

    errors = []
    for field, field_errors in form.errors.items():
        for error in field_errors:
            errors.append(error)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': False, 'message': ' '.join(errors)}), 400

    flash(' '.join(errors), 'error')
    return redirect(url_for('index') + '#help')


@app.route('/review', methods=['POST'])
def submit_review():
    """Recebe avaliação de um cliente."""
    form = ReviewForm()

    # Honeypot
    if form.website.data:
        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Avaliação enviada com sucesso!'})
        flash('Avaliação enviada com sucesso!', 'success')
        return redirect(url_for('index') + '#reviews')

    if form.validate_on_submit():
        image_filename = None
        if form.image.data:
            image_filename = save_upload(form.image.data, 'reviews')

        review = Review(
            name=form.name.data.strip(),
            service=form.service.data.strip(),
            rating=form.rating.data,
            comment=form.comment.data.strip(),
            image_filename=image_filename,
            approved=None  # Pendente
        )
        db.session.add(review)
        db.session.commit()

        if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
            return jsonify({'success': True, 'message': 'Avaliação enviada com sucesso! Ela será publicada após análise.'})

        flash('Avaliação enviada com sucesso! Ela será publicada após análise.', 'success')
        return redirect(url_for('index') + '#reviews')

    errors = []
    for field, field_errors in form.errors.items():
        for error in field_errors:
            errors.append(error)

    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return jsonify({'success': False, 'message': ' '.join(errors)}), 400

    flash(' '.join(errors), 'error')
    return redirect(url_for('index') + '#reviews')


# ──────────────────────────────────────
# ROTAS ADMIN — AUTENTICAÇÃO
# ──────────────────────────────────────

@app.route('/admin/login', methods=['GET', 'POST'])
def admin_login():
    """Página de login administrativo."""
    if current_user.is_authenticated:
        return redirect(url_for('admin_dashboard'))

    form = LoginForm()
    if form.validate_on_submit():
        admin = Admin.query.filter_by(username=form.username.data).first()
        if admin and admin.check_password(form.password.data):
            login_user(admin)
            flash('Login realizado com sucesso!', 'success')
            next_page = request.args.get('next')
            return redirect(next_page or url_for('admin_dashboard'))
        flash('Usuário ou senha incorretos.', 'error')

    return render_template('admin/login.html', form=form)


@app.route('/admin/logout')
@login_required
def admin_logout():
    logout_user()
    flash('Logout realizado.', 'success')
    return redirect(url_for('index'))


# ──────────────────────────────────────
# ROTAS ADMIN — DASHBOARD
# ──────────────────────────────────────

@app.route('/admin')
@login_required
def admin_dashboard():
    """Dashboard administrativo."""
    new_messages = ContactMessage.query.filter_by(read=False).count()
    total_messages = ContactMessage.query.count()
    new_help = HelpRequest.query.filter_by(status='new').count()
    total_help = HelpRequest.query.count()
    pending_reviews = Review.query.filter(Review.approved.is_(None)).count()
    approved_reviews = Review.query.filter_by(approved=True).count()

    return render_template('admin/dashboard.html',
                           new_messages=new_messages,
                           total_messages=total_messages,
                           new_help=new_help,
                           total_help=total_help,
                           pending_reviews=pending_reviews,
                           approved_reviews=approved_reviews)


# ──────────────────────────────────────
# ROTAS ADMIN — MENSAGENS
# ──────────────────────────────────────

@app.route('/admin/messages')
@login_required
def admin_messages():
    messages = ContactMessage.query.order_by(ContactMessage.created_at.desc()).all()
    return render_template('admin/messages.html', messages=messages)


@app.route('/admin/messages/<int:msg_id>')
@login_required
def admin_message_detail(msg_id):
    msg = ContactMessage.query.get_or_404(msg_id)
    # Marcar como lida ao visualizar
    if not msg.read:
        msg.read = True
        db.session.commit()
    return render_template('admin/message_detail.html', msg=msg)


@app.route('/admin/messages/<int:msg_id>/read', methods=['POST'])
@login_required
def admin_message_toggle_read(msg_id):
    msg = ContactMessage.query.get_or_404(msg_id)
    msg.read = not msg.read
    db.session.commit()
    flash(f'Mensagem marcada como {"lida" if msg.read else "não lida"}.', 'success')
    return redirect(url_for('admin_messages'))


@app.route('/admin/messages/<int:msg_id>/delete', methods=['POST'])
@login_required
def admin_message_delete(msg_id):
    msg = ContactMessage.query.get_or_404(msg_id)
    db.session.delete(msg)
    db.session.commit()
    flash('Mensagem excluída.', 'success')
    return redirect(url_for('admin_messages'))


# ──────────────────────────────────────
# ROTAS ADMIN — SOLICITAÇÕES DE AJUDA
# ──────────────────────────────────────

@app.route('/admin/help')
@login_required
def admin_help():
    requests_list = HelpRequest.query.order_by(HelpRequest.created_at.desc()).all()
    return render_template('admin/help_requests.html', requests=requests_list)


@app.route('/admin/help/<int:req_id>')
@login_required
def admin_help_detail(req_id):
    req = HelpRequest.query.get_or_404(req_id)
    return render_template('admin/help_detail.html', req=req)


@app.route('/admin/help/<int:req_id>/status', methods=['POST'])
@login_required
def admin_help_status(req_id):
    req = HelpRequest.query.get_or_404(req_id)
    new_status = request.form.get('status')
    if new_status in HelpRequest.STATUSES:
        req.status = new_status
        db.session.commit()
        flash(f'Status atualizado para: {req.status_label}', 'success')
    else:
        flash('Status inválido.', 'error')
    return redirect(url_for('admin_help_detail', req_id=req_id))


@app.route('/admin/help/<int:req_id>/delete', methods=['POST'])
@login_required
def admin_help_delete(req_id):
    req = HelpRequest.query.get_or_404(req_id)
    if req.image_filename:
        delete_upload(req.image_filename, 'help')
    db.session.delete(req)
    db.session.commit()
    flash('Solicitação excluída.', 'success')
    return redirect(url_for('admin_help'))


# ──────────────────────────────────────
# ROTAS ADMIN — AVALIAÇÕES
# ──────────────────────────────────────

@app.route('/admin/reviews')
@login_required
def admin_reviews():
    pending = Review.query.filter(Review.approved.is_(None)).order_by(Review.created_at.desc()).all()
    approved = Review.query.filter_by(approved=True).order_by(Review.created_at.desc()).all()
    rejected = Review.query.filter_by(approved=False).order_by(Review.created_at.desc()).all()
    return render_template('admin/reviews.html',
                           pending=pending, approved=approved, rejected=rejected)


@app.route('/admin/reviews/<int:rev_id>')
@login_required
def admin_review_detail(rev_id):
    review = Review.query.get_or_404(rev_id)
    return render_template('admin/review_detail.html', review=review)


@app.route('/admin/reviews/<int:rev_id>/approve', methods=['POST'])
@login_required
def admin_review_approve(rev_id):
    review = Review.query.get_or_404(rev_id)
    review.approved = True
    db.session.commit()
    flash('Avaliação aprovada!', 'success')
    return redirect(url_for('admin_reviews'))


@app.route('/admin/reviews/<int:rev_id>/reject', methods=['POST'])
@login_required
def admin_review_reject(rev_id):
    review = Review.query.get_or_404(rev_id)
    review.approved = False
    db.session.commit()
    flash('Avaliação rejeitada.', 'success')
    return redirect(url_for('admin_reviews'))


@app.route('/admin/reviews/<int:rev_id>/delete', methods=['POST'])
@login_required
def admin_review_delete(rev_id):
    review = Review.query.get_or_404(rev_id)
    if review.image_filename:
        delete_upload(review.image_filename, 'reviews')
    db.session.delete(review)
    db.session.commit()
    flash('Avaliação excluída.', 'success')
    return redirect(url_for('admin_reviews'))


# ──────────────────────────────────────
# ERROR HANDLERS
# ──────────────────────────────────────

@app.errorhandler(404)
def page_not_found(e):
    return render_template('errors/404.html'), 404


@app.errorhandler(500)
def internal_error(e):
    db.session.rollback()
    return render_template('errors/500.html'), 500


# ──────────────────────────────────────
# INICIAR APLICAÇÃO
# ──────────────────────────────────────

if __name__ == '__main__':
    init_app()
    print("\n" + "=" * 50)
    print("  Portfólio de Andrey Maia")
    print("  http://127.0.0.1:5000")
    print("  Admin: http://127.0.0.1:5000/admin/login")
    print("=" * 50 + "\n")
    app.run(debug=True, port=5000)
