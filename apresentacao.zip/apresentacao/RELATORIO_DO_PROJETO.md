# Relatório do Projeto — Portfólio de Andrey Maia

Visão geral do estado atual do site, para quem (pessoa ou IA) for dar manutenção.

---

## 1. Sobre o projeto

- **Dono:** Andrey Maia, técnico de suporte em informática (Help Desk em uma faculdade de Odontologia: manutenção, redes, suporte ao usuário e infraestrutura), estudante de Tecnologia da Informação e desenvolvedor web.
- **Objetivo:** apresentação pessoal e vitrine de serviços. O site atrai clientes que precisam de suporte técnico e também recrutadores de vagas de TI.
- **Stack:** Flask + SQLAlchemy (SQLite/MySQL) no back-end; HTML, CSS e JavaScript puros no front-end, sem frameworks.

---

## 2. Identidade visual

- **Cores** (variáveis no topo de `static/css/site.css`):
  - Fundo grafite: `--bg #0B0E11`, `--bg-2 #11151A`, `--bg-3 #181D23`
  - Texto: `--ink #E6EAED`, `--ink-2 #9BA5AF`, `--ink-3 #5F6974`
  - Destaque (botões, indicadores, detalhes): `--life #22D3EE` (ciano elétrico). No tema claro, textos em destaque usam `--life-ink #0E7490`.
  - Secundária: `--anchor #3D6BFF` (azul cobalto)
- **Fontes:** *Syne* (títulos grandes), *Instrument Sans* (texto corrido) e *JetBrains Mono* (números, rótulos e detalhes técnicos).
- **Temas:** escuro (padrão) e claro, alternados pelo botão no cabeçalho e salvos no `localStorage`.
- **Estilo:** cantos retos, linhas finas de grade aparentes, numeração de seções (`01 // SOBRE`), sombras duras em azul.

---

## 3. Seções da página (`templates/index.html`)

| Âncora | Conteúdo |
|---|---|
| `#hero` | Nome "ANDREY / MAIA" em letras grandes (MAIA vazado), foto da bancada ao lado, relógio de Fortaleza, frase de apresentação e botões "Ver projetos" / "Preciso de suporte". |
| `#about` | 01 · Sobre: manifesto, texto biográfico, tags de tecnologia e painel com 3 números expansíveis (100+ computadores, 3 sistemas web, 10+ qualificações). |
| `#skills` | 02 · Habilidades: grade (bento) com Hardware, Suporte ao Usuário, Redes, Programação, Programação com IA e Ferramentas, mais o card "Sempre em build". |
| `#services` | 03 · Serviços: 5 linhas (Manutenção, Suporte Técnico, Redes, Desenvolvimento Web, Automação e IA). Seção em cores invertidas. |
| `#projects` | 04 · Projetos: Sistema de Controle Logístico (destaque), Adilson Motos e JM Hardware & Informática. |
| `#reviews` | 05 · Avaliações: depoimentos aprovados, média de notas e formulário de avaliação com foto. |
| `#help` | Help Desk: formulário "Preciso de ajuda" no formato de ticket. |
| `#contact` | 06 · Contato: formulário de mensagem e dados de contato. |

---

## 4. Comportamentos (`static/js/script.js`)

- **Boot:** tela de inicialização estilo terminal na primeira visita da sessão.
- **Hero:** letras do nome entram uma a uma; a foto acompanha o mouse levemente.
- **Scroll:** elementos aparecem ao rolar, o manifesto "acende" palavra por palavra e o menu marca a seção atual.
- **Medidores e contadores:** barras de habilidade e números animam quando entram na tela.
- **Painel de números:** ao passar o mouse ou clicar, um card se expande e mostra os detalhes; os outros recolhem.
- **Extras:** efeito de digitação, relógio ao vivo, botões magnéticos, cursor contextual, número de ticket gerado no formulário de ajuda.
- **Formulários:** enviados por `fetch`, com nota de 1 a 5, pré-visualização de imagem e mensagens que somem sozinhas.

---

## 5. Back-end

- **Rotas públicas:** `/` (página), `/contact`, `/help` e `/review` (POST dos formulários), `/uploads/<arquivo>`.
- **Painel (`/admin`):** login, dashboard, mensagens, chamados (com status e botão de WhatsApp) e moderação de avaliações.
- **Tabelas (`models.py`):** `Admin`, `ContactMessage`, `HelpRequest`, `Review`.
- **Configuração:** `config.py` lê o `.env` (chave secreta, banco, usuário e senha do admin, limite de upload).

---

## 6. Responsividade

Pontos de quebra em `1180px` (menu vira hambúrguer), `1024px` (grades viram uma coluna) e `768px` (celular: foto do hero some para o nome caber inteiro, cards empilham).
