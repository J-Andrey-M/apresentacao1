import os
from dotenv import load_dotenv

load_dotenv()

basedir = os.path.abspath(os.path.dirname(__file__))


class Config:
    """Configurações da aplicação Flask."""

    # Diretório base
    BASE_DIR = basedir

    # Segurança
    SECRET_KEY = os.environ.get('SECRET_KEY', 'dev-fallback-key-change-me')

    # Banco de dados (Fallback para caminho absoluto do SQLite)
    _db_url = os.environ.get('DATABASE_URL')
    if _db_url and not _db_url.startswith('sqlite:///instance/'):
        SQLALCHEMY_DATABASE_URI = _db_url
    else:
        instance_dir = os.path.join(basedir, 'instance')
        os.makedirs(instance_dir, exist_ok=True)
        SQLALCHEMY_DATABASE_URI = f"sqlite:///{os.path.join(instance_dir, 'database.db')}"

    SQLALCHEMY_TRACK_MODIFICATIONS = False

    # Uploads
    MAX_CONTENT_LENGTH = int(os.environ.get('MAX_UPLOAD_SIZE', 5242880))  # 5MB
    UPLOAD_FOLDER = os.path.join(basedir, 'uploads')
    ALLOWED_EXTENSIONS = {'jpg', 'jpeg', 'png', 'webp'}

    # Admin
    ADMIN_USERNAME = os.environ.get('ADMIN_USERNAME', 'andrey')
    ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'troque_esta_senha')
