from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileAllowed
from wtforms import (
    StringField, TextAreaField, PasswordField,
    SelectField, HiddenField, IntegerField
)
from wtforms.validators import (
    DataRequired, Email, Length, NumberRange, Optional
)


class LoginForm(FlaskForm):
    """Formulário de login administrativo."""

    username = StringField('Usuário', validators=[
        DataRequired(message='Informe o usuário.'),
        Length(max=80)
    ])
    password = PasswordField('Senha', validators=[
        DataRequired(message='Informe a senha.')
    ])


class ContactForm(FlaskForm):
    """Formulário 'Vamos Conversar'."""

    name = StringField('Nome', validators=[
        DataRequired(message='Informe seu nome.'),
        Length(min=2, max=120, message='Nome deve ter entre 2 e 120 caracteres.')
    ])
    email = StringField('E-mail', validators=[
        DataRequired(message='Informe seu e-mail.'),
        Email(message='E-mail inválido.'),
        Length(max=120)
    ])
    whatsapp = StringField('WhatsApp', validators=[
        Optional(),
        Length(max=20)
    ])
    subject = StringField('Assunto', validators=[
        Optional(),
        Length(max=200)
    ])
    message = TextAreaField('Mensagem', validators=[
        DataRequired(message='Escreva sua mensagem.'),
        Length(min=10, max=5000, message='Mensagem deve ter entre 10 e 5000 caracteres.')
    ])
    # Honeypot anti-spam
    website = HiddenField()


class HelpRequestForm(FlaskForm):
    """Formulário 'Preciso de Ajuda'."""

    name = StringField('Nome', validators=[
        DataRequired(message='Informe seu nome.'),
        Length(min=2, max=120)
    ])
    email = StringField('E-mail', validators=[
        DataRequired(message='Informe seu e-mail.'),
        Email(message='E-mail inválido.'),
        Length(max=120)
    ])
    whatsapp = StringField('WhatsApp', validators=[
        DataRequired(message='Informe seu WhatsApp.'),
        Length(max=20)
    ])
    service = SelectField('Serviço', choices=[
        ('', 'Selecione o serviço'),
        ('manutencao', 'Manutenção de computador'),
        ('suporte', 'Suporte técnico'),
        ('rede', 'Rede / Wi-Fi'),
        ('desenvolvimento', 'Desenvolvimento web'),
        ('automacao', 'Automação e IA'),
        ('outro', 'Outro'),
    ], validators=[Optional()])
    description = TextAreaField('Descrição do problema', validators=[
        DataRequired(message='Descreva o problema.'),
        Length(min=10, max=5000)
    ])
    image = FileField('Foto do problema', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'webp'], 'Apenas imagens (JPG, PNG, WebP).')
    ])
    # Honeypot
    website = HiddenField()


class ReviewForm(FlaskForm):
    """Formulário de avaliação."""

    name = StringField('Nome', validators=[
        DataRequired(message='Informe seu nome.'),
        Length(min=2, max=120)
    ])
    service = StringField('Serviço realizado', validators=[
        DataRequired(message='Informe o serviço.'),
        Length(max=100)
    ])
    rating = IntegerField('Nota', validators=[
        DataRequired(message='Selecione uma nota.'),
        NumberRange(min=1, max=5, message='Nota deve ser entre 1 e 5.')
    ])
    comment = TextAreaField('Comentário', validators=[
        DataRequired(message='Escreva seu comentário.'),
        Length(min=10, max=2000)
    ])
    image = FileField('Foto', validators=[
        Optional(),
        FileAllowed(['jpg', 'jpeg', 'png', 'webp'], 'Apenas imagens (JPG, PNG, WebP).')
    ])
    # Honeypot
    website = HiddenField()
