from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash

db = SQLAlchemy()


class Admin(UserMixin, db.Model):
    """Administrador do sistema."""

    __tablename__ = 'admin'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def set_password(self, password):
        self.password_hash = generate_password_hash(password)

    def check_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return f'<Admin {self.username}>'


class ContactMessage(db.Model):
    """Mensagens recebidas pelo formulário 'Vamos Conversar'."""

    __tablename__ = 'contact_message'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    whatsapp = db.Column(db.String(20), nullable=True)
    subject = db.Column(db.String(200), nullable=True)
    message = db.Column(db.Text, nullable=False)
    read = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    def __repr__(self):
        return f'<ContactMessage {self.name} - {self.subject}>'


class HelpRequest(db.Model):
    """Solicitações de ajuda/atendimento."""

    __tablename__ = 'help_request'

    STATUSES = ['new', 'contacted', 'in_progress', 'completed', 'cancelled']
    STATUS_LABELS = {
        'new': 'Nova',
        'contacted': 'Contatada',
        'in_progress': 'Em andamento',
        'completed': 'Concluída',
        'cancelled': 'Cancelada',
    }

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    email = db.Column(db.String(120), nullable=False)
    whatsapp = db.Column(db.String(20), nullable=False)
    service = db.Column(db.String(100), nullable=True)
    description = db.Column(db.Text, nullable=False)
    image_filename = db.Column(db.String(255), nullable=True)
    status = db.Column(db.String(20), default='new')
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def status_label(self):
        return self.STATUS_LABELS.get(self.status, self.status)

    def __repr__(self):
        return f'<HelpRequest {self.name} - {self.service}>'


class Review(db.Model):
    """Avaliações dos clientes."""

    __tablename__ = 'review'

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(120), nullable=False)
    service = db.Column(db.String(100), nullable=False)
    rating = db.Column(db.Integer, nullable=False)  # 1-5
    comment = db.Column(db.Text, nullable=False)
    image_filename = db.Column(db.String(255), nullable=True)
    approved = db.Column(db.Boolean, nullable=True, default=None)  # None=pendente, True=aprovada, False=rejeitada
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

    @property
    def status_label(self):
        if self.approved is None:
            return 'Pendente'
        return 'Aprovada' if self.approved else 'Rejeitada'

    def __repr__(self):
        return f'<Review {self.name} - {self.rating}★>'
